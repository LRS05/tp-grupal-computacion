#!/bin/bash

# Configuramos el comando de ayuda y verificamos la cantidad de parametros
if [ "$1" = "-help" ]; then
    echo "Uso: $0 <origen> <destino>"
    echo "Ejemplo: $0 /var/log /backup_dir"
    exit 0
fi

if [ $# -ne 2 ]; then
    echo "Parametros incorrectos."
    echo "Use: $0 -help"
    exit 1
fi

ORIGEN=$1
DESTINO=$2

# Verificamos si ambos directorios existen
if [ ! -d "$ORIGEN" ]; then
    echo "El directorio origen no existe."
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "El directorio destino no existe."
    exit 1
fi

# Verificamos que el destino este montado
if [ ! mountpoint -q "$DESTINO" ]; then
    echo "$DESTINO no esta montado."
    exit 1
fi


# Toma el ultimo nombre de la ruta origen
NOMBRE=$(basename "$ORIGEN")

# Toma la fecha en el formato dado.
FECHA=$(date +%Y%m%d)

# Creamos el script dentro de origen con el formato solicitado.
tar -czf "$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz" "$ORIGEN"

if [ $? -eq 0 ]; then
    echo "Backup generado correctamente."
else
    echo "Error al generar el backup."
fi


